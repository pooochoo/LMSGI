document.getElementById("btn").addEventListener("click", cambiarColor() );

function cambiarColor() {
    const color = document.getElementById("titulo");
    color.style.color = "red";
}

